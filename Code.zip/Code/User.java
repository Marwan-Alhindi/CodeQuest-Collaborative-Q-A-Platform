import java.util.List;

public abstract class User {
    protected int userID;
    protected String ipAddress;
    protected String username;
    protected String password;
    protected String email;
    protected List<Post> posts;

    // Constructor
    public User(int userID, String ipAddress, String username, String password, String email) {
        this.userID = userID;
        this.ipAddress = ipAddress;
        this.username = username;
        this.password = password;
        this.email = email;
    }

    // Abstract method
    public abstract void deletePost(Post post);

    // Concrete methods
    public void createQuestion(String title, String content) {
    }

    public void createAnswer(String content) {
    }

    public void createComment(String content) {
    }

    // Getters and Setters

    public int getUserID() {
        return this.userID;
    }

    public String getIpAddress() {
        return this.ipAddress;
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }

    public String getEmail() {
        return this.email;
    }

    public List<Post> getPosts() {
        return this.posts;
    }
}
