public class PermissionsManager {

    public boolean removalAllowed(User author) {

        // If the author is another moderator
        // The post should not be removed
        // So display an error message and return false
        if (author instanceof Moderator) {
            this.displayErrorMessage();
            return false;
        } else {
            return true;
        }
    }

    public void displayErrorMessage() {
        // no need to implement this
    }
}
