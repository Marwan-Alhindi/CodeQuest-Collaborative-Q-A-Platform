import java.util.Date;

public class Moderator extends User {
    private NotificationManager notificationManager = new NotificationManager();
    private BanLog banLog = new BanLog();

    public void banUser(User user, int banDuration) {
        user.setBannedStatus(true); // Ban user
        banLog.addUser(user); // Add user to banned user list

        // Use a zero or negative banDuration value to set indefinite ban
        if (banDuration > 0) {
            user.setBanEndDate(banDuration); // Ban user for banDuration number of days
        }
        notificationManager.sendBanMessage(user); // Notify user of ban

    }
}