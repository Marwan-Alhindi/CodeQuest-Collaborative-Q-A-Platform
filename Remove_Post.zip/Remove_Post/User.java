import java.util.List;

public class User {
    protected String userName;
    protected List<Notification> notifications;
    protected List<Post> posts;

    public String getUserName() {
        return this.userName;
    }

    // Method to add a new notification to user's notifications
    public void addNotification(Notification notification) {
        notifications.add(notification);
    }
}
