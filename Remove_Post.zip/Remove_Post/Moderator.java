public class Moderator extends User {
    private PermissionsManager permissionsManager = new PermissionsManager();
    private NotificationManager notificationManager = new NotificationManager();

    public void removePost(Post post) {
        User author = post.getAuthor(); // get the author of the post to remove

        boolean removalApproved = permissionsManager.removalAllowed(author);
        if (removalApproved == false) {
            return; // if removal is not approved then exit
        } else {
            notificationManager.sendRemovalNotification(post, author);
            post.setVisible(false); // The post is still stored in the database
                                    // but no longer visible on the website
        }
        return;
    }
}