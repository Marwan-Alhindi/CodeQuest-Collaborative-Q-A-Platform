import java.util.List;

public class Topic {
    private String topicName;
    private List<Question> questionList;
    private List<Moderator> modList;

    // Constructor
    public Topic(String topicName) {
        this.topicName = topicName;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public List<Question> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(List<Question> questionList) {
        this.questionList = questionList;
    }

    public List<Moderator> getModList() {
        return modList;
    }

    public void setModList(List<Moderator> modList) {
        this.modList = modList;
    }

    public void updateModList(Moderator moderator) {
    }

    public void updateQuestionList(Question question) {
    }

}
