import java.util.List;
import java.util.Calendar;
import java.util.Date;

public class User {
    protected String userName;
    protected List<Notification> notifications;
    protected boolean bannedStatus;
    protected Date banEndDate;

    public void setBannedStatus(boolean bannedStatus) {
        this.bannedStatus = bannedStatus;
    }

    public void setBanEndDate(int duration) {
        // This methods takes the ban duration specified by moderator in days
        // And calculates the ban end date
        Date currentDate = new Date(); // initialised at current date

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.DATE, duration); // Adding duration to get endDate
        Date endDate = calendar.getTime();
        this.banEndDate = endDate;
    }

    public Date getBanEndDate() {
        return banEndDate;
    }

    public String getUserName() {
        return this.userName;
    }

    // Method to add a new notification to user's notifications
    public void addNotification(Notification notification) {
        notifications.add(notification);
    }
}
