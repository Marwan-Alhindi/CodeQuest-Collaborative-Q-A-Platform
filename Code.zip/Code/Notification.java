import java.util.Date;

public class Notification {
    private int notificationId;
    private User recipient;
    private String message;
    private boolean readStatus;

    // Default constructor
    public Notification() {

    }

    public Notification(int notificationId, User recipient, String message) {
        this.notificationId = notificationId;
        this.recipient = recipient;
        this.message = message;
        this.readStatus = false; // Assuming notifications are initially unread
    }

    public void setReadStatus(boolean readStatus) {
        this.readStatus = readStatus;
    }

    public Notification setReminder(Date reminderDate) {
        Notification newNotification = new Notification();
        return newNotification;
    }

    // Getters and Setters

    public boolean getReadStatus() {
        return this.readStatus;
    }

    public int getNotificationId() {
        return this.notificationId;
    }

    public User getRecipient() {
        return this.recipient;
    }

    public String getMessage() {
        return this.message;
    }
}
