import java.util.Date;

public class Comment extends Post {
    private int parentPostID;
    private String questionPostID;

    // Constructor
    public Comment(String postId, String content, User author, Date createdDate, int parentPostID,
            String questionPostID) {
        super(postId, content, author, createdDate);
        this.parentPostID = parentPostID;
        this.questionPostID = questionPostID;
    }

    @Override
    public void editPost() {
    }

    @Override
    public void displayPost() {
    }

    public int getParentPostID() {
        return parentPostID;
    }

    public void setParentPostID(int parentPostID) {
        this.parentPostID = parentPostID;
    }

    public String getQuestionPostID() {
        return questionPostID;
    }

    public void setQuestionPostID(String questionPostID) {
        this.questionPostID = questionPostID;
    }

}
