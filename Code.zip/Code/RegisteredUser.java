public class RegisteredUser extends User {
    private int reputationPoints;
    private String userBio;

    // Constructor
    public RegisteredUser(int userID, String ipAddress, String username, String password, String email,
            int reputationPoints, String userBio) {
        super(userID, ipAddress, username, password, email);
        this.reputationPoints = reputationPoints;
        this.userBio = userBio;
    }

    public void vote(Post post, boolean direction) {
    }

    @Override
    public void deletePost(Post post) {
    }

    public int getReputationPoints() {
        return this.reputationPoints;
    }

    public String getUserBio() {
        return this.userBio;
    }
}
