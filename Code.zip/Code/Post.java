import java.util.Date;

public abstract class Post {
    protected String postId;
    protected String content;
    protected User author;
    protected Date createdDate;
    protected int voteCount;

    // Constructor
    public Post(String postId, String content, User author, Date createdDate) {
        this.postId = postId;
        this.content = content;
        this.author = author;
        this.createdDate = createdDate;
        this.voteCount = 0;
    }

    // Abstract methods
    public abstract void editPost();

    public abstract void displayPost();
    // A method that sends the post content to the website

}
