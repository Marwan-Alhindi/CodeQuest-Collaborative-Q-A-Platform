public class Post {
    private User author;
    private String postTitle;
    private boolean visible;

    // Setters and getters:
    public User getAuthor() {
        return this.author;
    }

    public String getPostTitle() {
        return this.postTitle;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
}