import java.util.List;

public class Admin extends Moderator {
    private String rank;
    private List<Moderator> addedModerators;

    public Admin(int userID, String ipAddress, String username, String password, String email, String rank) {
        super(userID, ipAddress, username, password, email);
        this.rank = rank;
    }

    public void addModerator(int userID) {
    }

    public void removeModerator(int userID) {
    }

}
