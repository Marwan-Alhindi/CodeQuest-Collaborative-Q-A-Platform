import java.util.List;

public class AutoModerator extends Moderator {
    private List<String> bannedWords;
    private String removalMessage;

    public AutoModerator(int userID, String ipAddress, String username, String password, String email) {
        super(userID, ipAddress, username, password, email);
    }

    public Post flagPost() {
        return null;
    }

    public double estimateSpamProbability() {
        return 0.0;
    }

    public List<String> getBannedWords() {
        return bannedWords;
    }

    public void setBannedWords(List<String> bannedWords) {
        this.bannedWords = bannedWords;
    }

    public String getRemovalMessage() {
        return removalMessage;
    }

    public void setRemovalMessage(String removalMessage) {
        this.removalMessage = removalMessage;
    }

}
