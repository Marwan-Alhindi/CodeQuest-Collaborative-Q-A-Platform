import java.util.List;

public class Tag {
    private String tagName;
    private List<Question> questionList;

    // Constructor
    public Tag(String tagName) {
        this.tagName = tagName;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public List<Question> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(List<Question> questionList) {
        this.questionList = questionList;
    }

    public void addQuestion(Question question) {
    }

    public void removeQuestion(Question question) {
    }

}
