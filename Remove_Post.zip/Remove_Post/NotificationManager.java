public class NotificationManager {

    public void sendRemovalNotification(Post post, User author) {
        String messageContent = "Dear " + author.getUserName() + ", your post \'" + post.getPostTitle()
                + " has been removed."; // construct user message
        Notification notification = new Notification(messageContent); // create notification with messageContent
        author.addNotification(notification); // add notification to author's notifications
    }
}
