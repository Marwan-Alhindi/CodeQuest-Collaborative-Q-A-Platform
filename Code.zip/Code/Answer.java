import java.util.Date;

public class Answer extends Post {
    private String questionPostID;
    private boolean answerAccepted;

    // Constructor
    public Answer(String postId, String content, User author, Date createdDate, String questionPostID) {
        super(postId, content, author, createdDate);
        this.questionPostID = questionPostID;
        this.answerAccepted = false; // Assuming initially not accepted
    }

    public String getQuestionPostID() {
        return questionPostID;
    }

    public void setQuestionPostID(String questionPostID) {
        this.questionPostID = questionPostID;
    }

    public boolean isAnswerAccepted() {
        return answerAccepted;
    }

    public void setAnswerAccepted(boolean answerAccepted) {
        this.answerAccepted = answerAccepted;
    }

    @Override
    public void editPost() {
    }

    @Override
    public void displayPost() {
    }

}
