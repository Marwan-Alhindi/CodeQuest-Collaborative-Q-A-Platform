import java.util.List;

public class Moderator extends User {
    private List<Topic> topics;
    private List<Post> reviewQueue;

    // Constructor
    public Moderator(int userID, String ipAddress, String username, String password, String email) {
        super(userID, ipAddress, username, password, email);
    }

    // Additional constructor
    public Moderator(int userID, String ipAddress, String username, String password, String email, List<Topic> topics,
            List<Post> reviewQueue) {
        super(userID, ipAddress, username, password, email);
        this.topics = topics;
        this.reviewQueue = reviewQueue;
    }

    public void removePost(Post post) {
    }

    public void banUser(User user) {
    }

    @Override
    public void deletePost(Post post) {
    }

}
