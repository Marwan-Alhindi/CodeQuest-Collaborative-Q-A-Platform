public class Notification {
    private String messageContent;

    // Constructor
    public Notification(String messageContent) {
        this.messageContent = messageContent;
    }

}
