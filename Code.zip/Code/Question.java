import java.util.Date;
import java.util.List;

public class Question extends Post {
    private boolean answered;
    private String title;
    private List<String> tagList;

    // Constructor
    public Question(String postId, String content, User author, Date createdDate, String title, List<String> tagList) {
        super(postId, content, author, createdDate);
        this.title = title;
        this.tagList = tagList;
        this.answered = false;
    }

    public void acceptAnswer() {
    }

    @Override
    public void editPost() {
    }

    @Override
    public void displayPost() {
    }

    public boolean isAnswered() {
        return answered;
    }

    public void setAnswered(boolean answered) {
        this.answered = answered;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getTagList() {
        return tagList;
    }

    public void setTagList(List<String> tagList) {
        this.tagList = tagList;
    }

}
