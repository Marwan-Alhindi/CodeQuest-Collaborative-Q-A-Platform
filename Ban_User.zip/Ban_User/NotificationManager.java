import java.util.Date;

public class NotificationManager {

    public void sendBanMessage(User user) {
        Date endDate = user.getBanEndDate(); // Get ban end date if any
        String message = "Dear " + user.userName + " you have been banned"; // Construct ban message
        if (endDate != null) {
            message += " until " + endDate;
        }

        Notification notification = new Notification(message);
        user.addNotification(notification); // Add to user's notifications
    }
}
