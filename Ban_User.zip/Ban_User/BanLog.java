import java.util.List;

public class BanLog {
    private static List<User> bannedUsers;

    public void addUser(User user) {
        bannedUsers.add(user);
    }
}
